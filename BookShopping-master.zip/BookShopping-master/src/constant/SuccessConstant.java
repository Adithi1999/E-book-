package constant;

public final class SuccessConstant {
	public static final String LOGIN_MESSAGE1 = "018";
	public static final String REGISTER_MESSAGE = "019";
	
	
	public static final String BOOK_ADDED_MESSAGE1 = "29";
	public static final String BOOK_ADDED_MESSAGE2 = "30";
	
	public static final String UPADTE_CART_MESSAGE1 = "101";
	public static final String UPADTE_CART_MESSAGE2 = "102";
	public static final String UPADTE_CART_MESSAGE3 = "103";

	
	public static final String PAYMENT_SUCCESS_MESSAGE1 = "051";
	public static final String PAYMENT_SUCCESS_MESSAGE2 = "052";
	public static final String PAYMENT_SUCCESS_MESSAGE3 = "053";
	public static final String PAYMENT_SUCCESS_MESSAGE4 = "054";
	public static final String PAYMENT_SUCCESS_MESSAGE5 = "055";
}
