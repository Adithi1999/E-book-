package vo;

public class RegisterVo {
   private int card_id;
   private int cus_id;
   private String cus_name;
   private String cus_pass;
   private String cus_dob;
   private String cus_addr;
   private String cus_cont;
   private String cus_email;
   public int getCard_id() {
	return card_id;
}
public void setCard_id(int card_id) {
	this.card_id = card_id;
}
public int getCus_id() {
	return cus_id;
}
public void setCus_id(int cus_id) {
	this.cus_id = cus_id;
}
public String getCus_name() {
	return cus_name;
}
public void setCus_name(String cus_name) {
	this.cus_name = cus_name;
}
public String getCus_pass() {
	return cus_pass;
}
public void setCus_pass(String cus_pass) {
	this.cus_pass = cus_pass;
}
public String getCus_dob() {
	return cus_dob;
}
public void setCus_dob(String cus_dob) {
	this.cus_dob = cus_dob;
}
public String getCus_addr() {
	return cus_addr;
}
public void setCus_addr(String cus_addr) {
	this.cus_addr = cus_addr;
}
public String getCus_cont() {
	return cus_cont;
}
public void setCus_cont(String cus_cont) {
	this.cus_cont = cus_cont;
}
public String getCus_email() {
	return cus_email;
}
public void setCus_email(String cus_email) {
	this.cus_email = cus_email;
}

   
   
}
